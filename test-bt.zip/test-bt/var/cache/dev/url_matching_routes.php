<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/users/([^/]++)/password(?'
                    .'|(*:34)'
                    .'|/verify(*:48)'
                .')'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        34 => [[['_route' => 'generatePassword', '_controller' => 'App\\Controller\\UserController::generatePassword'], ['userId'], ['POST' => 0], null, false, false, null]],
        48 => [
            [['_route' => 'verifyPassword', '_controller' => 'App\\Controller\\UserController::verifyPassword'], ['userId'], ['POST' => 0], null, false, false, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
